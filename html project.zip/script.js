function abc(){
    window.alert("YOUR DATA IS BEING PROCCESSED")
    document.write("BE PATIENT YOU WILL RECEIVE YOUR BLOOD SOON")
}
function cdf(){
    window.alert("THANK YOU FOR YOUR SERVICE")
    document.write("WE REALLY APPRECIATE YOUR HELP TO SAVE LIFE BY DONATING YOUR BLOOD")
}
